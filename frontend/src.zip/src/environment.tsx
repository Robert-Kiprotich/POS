export const base_path = "/";
export const image_path = "/static/frontend/";